import{_ as r}from"./CPCtvw1X.js";import{O as e,H as c}from"./BUEL6RMO.js";const o={};function t(n,a){return c(),e("div",null,"repair")}const f=r(o,[["render",t]]);export{f as default};
