import{p as s}from"./CRrJtDm0.js";const o=s("/images/bg.png");export{o as _};
