import{_ as e}from"./CPCtvw1X.js";import{O as t,H as r}from"./BUEL6RMO.js";const c={};function o(n,s){return r(),t("div",null,"cutter")}const f=e(c,[["render",o]]);export{f as default};
