// ROLLUP_NO_REPLACE 
 const zh = "{\"parsed\":{\"_path\":\"/home/zh\",\"_dir\":\"home\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"_id\":\"content:home:zh.json\",\"_type\":\"json\",\"title\":\"Zh\",\"_source\":\"content\",\"_file\":\"home/zh.json\",\"_stem\":\"home/zh\",\"_extension\":\"json\"},\"hash\":\"qztWLH2C68\"}";

export { zh as default };
//# sourceMappingURL=zh.mjs.map
