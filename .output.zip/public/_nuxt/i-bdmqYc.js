import{p as s}from"./CPCtvw1X.js";const o=s("/images/bg.png");export{o as _};
