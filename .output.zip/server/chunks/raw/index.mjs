// ROLLUP_NO_REPLACE 
 const index = "{\"parsed\":{\"_path\":\"/\",\"_dir\":\"\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"title\":\"123\",\"_id\":\"content:index.json\",\"_type\":\"json\",\"_source\":\"content\",\"_file\":\"index.json\",\"_stem\":\"index\",\"_extension\":\"json\"},\"hash\":\"HIG3iZhXHc\"}";

export { index as default };
//# sourceMappingURL=index.mjs.map
