// ROLLUP_NO_REPLACE 
 const contentIndex = "{\"/\":[\"content:index.json\"],\"/about/en\":[\"content:about:en.json\"],\"/about/zh\":[\"content:about:zh.json\"],\"/home/en\":[\"content:home:en.json\"],\"/home/zh\":[\"content:home:zh.json\"],\"/layout/en\":[\"content:layout:en.json\"],\"/layout/zh\":[\"content:layout:zh.json\"],\"/probes/en/400mini\":[\"content:probes:en:400mini.json\"],\"/probes/en/400ms\":[\"content:probes:en:400ms.json\"],\"/probes/en\":[\"content:probes:en:index.json\"],\"/probes/zh/400mini\":[\"content:probes:zh:400mini.json\"],\"/probes/zh/400ms\":[\"content:probes:zh:400ms.json\"],\"/probes/zh\":[\"content:probes:zh:index.json\"]}";

export { contentIndex as default };
//# sourceMappingURL=content-index.mjs.map
