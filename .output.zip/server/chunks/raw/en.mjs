// ROLLUP_NO_REPLACE 
 const en = "{\"parsed\":{\"_path\":\"/home/en\",\"_dir\":\"home\",\"_draft\":false,\"_partial\":false,\"_locale\":\"\",\"_id\":\"content:home:en.json\",\"_type\":\"json\",\"title\":\"En\",\"_source\":\"content\",\"_file\":\"home/en.json\",\"_stem\":\"home/en\",\"_extension\":\"json\"},\"hash\":\"jxBfCcLmtq\"}";

export { en as default };
//# sourceMappingURL=en.mjs.map
