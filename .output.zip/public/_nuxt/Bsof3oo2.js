import{_ as r}from"./CPCtvw1X.js";import{H as e,O as o}from"./BUEL6RMO.js";const c={};function t(n,s){return e(),o("hr")}const f=r(c,[["render",t]]);export{f as default};
